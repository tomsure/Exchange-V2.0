package com.broctagon.webgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebgatewayApp {
	
    public static void main(String[] args ){
    	SpringApplication.run(WebgatewayApp.class, args);
    }
    
}
